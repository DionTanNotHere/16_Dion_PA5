﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;


public class Player : MonoBehaviour
{
    public Text CoinTxt;
    private int coin = 0;
    public float speed;
    Rigidbody thisrigidbody;
    void Start()
    {
        thisrigidbody = GetComponent<Rigidbody>();
    }

    
    void Update()
    {
        float moveHorizontal = Input.GetAxis("Horizontal");
        float moveVertical = Input.GetAxis("Vertical");
        Vector3 movement = new Vector3(moveHorizontal, 0, moveVertical);
        thisrigidbody.AddForce(movement * speed * Time.deltaTime);
        if(coin==4)
        {
            SceneManager.LoadScene("Win");
        }
    }
    private void OnCollisionEnter(Collision collision)
    {
        if(collision.collider.tag=="Bad")
        {
            SceneManager.LoadScene("Lose");
        }
        if (collision.collider.tag == "Coin")
        {
            Destroy(collision.gameObject);
            coin++;
            CoinTxt.text = "Coin Collected :" + coin;
        }
    }
}
